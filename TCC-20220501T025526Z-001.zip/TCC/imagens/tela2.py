# Importação de bibliotecas ou módulos
from tkinter import *
from PIL import ImageTk, Image

menu = Tk()

menu.title("S.A.P.D.A.")
menu.resizable(1, 1)

#Concfigurando imagens
#Carro
carro1 = Image.open("car.png")
resized1 = carro1.resize((300, 200), Image.ANTIALIAS)
car = ImageTk.PhotoImage(resized1)
##Sinais
esquerda1 = Image.open("esquerda.png")
resized2 = esquerda1.resize((150, 100), Image.ANTIALIAS)
left = ImageTk.PhotoImage(resized2)
direita1 = Image.open("direita.png")
resized3 = direita1.resize((150, 100), Image.ANTIALIAS)
right = ImageTk.PhotoImage(resized3)

my_label1 = Label(menu, image=car)
my_label1.grid(row=1, column=1)
my_label2 = Label(menu, image=left)
my_label2.grid(row=1, column=0)
my_label3 = Label(menu, image=right)
my_label3.grid(row=1, column=2)

menu.mainloop()





